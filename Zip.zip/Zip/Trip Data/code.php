<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_tripData']))
{
    $tripData_id = mysqli_real_escape_string($con, $_POST['delete_tripData']);

    $query = "DELETE FROM trip_database WHERE id='$tripData_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_tripData']))
{
    $tripData_id = mysqli_real_escape_string($con, $_POST['tripData_id']);

    $Trip_ID = mysqli_real_escape_string($con, $_POST['Trip_ID']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $Order_Out_Date = mysqli_real_escape_string($con, $_POST['Order_Out_Date']);
    $Received_Date = mysqli_real_escape_string($con, $_POST['Received_Date']);
    $Delivery_ID = mysqli_real_escape_string($con, $_POST['Delivery_ID']);
    $Total_Mileage = mysqli_real_escape_string($con, $_POST['Total_Mileage']);

    $query = "UPDATE trip_database SET Trip_ID='$Trip_ID', CurrentStatus='$CurrentStatus', Order_Out_Date='$Order_Out_Date', Received_Date='$Received_Date' Delivery_ID='$Delivery_ID', Total_Mileage='$Total_Mileage' WHERE id='$tripData_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Updated";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['save_tripData']))
{
    $Trip_ID = mysqli_real_escape_string($con, $_POST['Trip_ID']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $Order_Out_Date = mysqli_real_escape_string($con, $_POST['Order_Out_Date']);
    $Received_Date = mysqli_real_escape_string($con, $_POST['Received_Date']);
    $Delivery_ID = mysqli_real_escape_string($con, $_POST['Delivery_ID']);
    $Total_Mileage = mysqli_real_escape_string($con, $_POST['Total_Mileage']);

    $query = "INSERT INTO trip_database (Trip_ID, CurrentStatus, Order_Out_Date, Received_Date, Delivery_ID, Total_Mileage) VALUES ('$Trip_ID', '$CurrentStatus', '$Order_Out_Date', '$Received_Date', '$Delivery_ID', '$Total_Mileage')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Created Successfully";
        header("Location: tripData-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Created";
        header("Location: tripData-create.php");
        exit(0);
    }
}
?>
