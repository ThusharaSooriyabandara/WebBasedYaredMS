<?php 
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Vehicle Registration</title>
    <style>
         body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
  
     .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        .float-end {
            margin-left: auto;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-color: #ccc;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
    </style>
</head>
<body>
    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div>
  
    <div class="container">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header">
                <h4>Trip Data</h4>
                <a href="index.php" class="btn btn-danger float-end">BACK</a>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="Trip_ID" class="form-label">Trip ID</label>
                        <input type="text" id="Trip_ID" name="Trip_ID" class="form-control" placeholder="Trip ID">
                    </div>
                    <div class="mb-3">
                        <label for="CurrentStatus" class="form-label">Status</label><br>
                        <select id="CurrentStatus" name="CurrentStatus" class="form-select" onchange="showDateField()">
                            <option value="Order">Order</option>
                            <option value="Receiving">Receiving</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label id="dateLabel">Order Out Date</label>
                        <input type="datetime-local" id="Order_Out_Date" name="Order_Out_Date" class="form-control" placeholder="Date">
                    </div>
                    <div class="mb-3">
                        <label for="Delivery_ID" class="form-label">Order / Delivery ID</label>
                        <input type="text" id="Delivery_ID" name="Delivery_ID" class="form-control" placeholder="Order / Delivery ID">
                    </div>
                    <div class="mb-3">
                        <label for="Total_Mileage" class="form-label">Total Mileage</label>
                        <input type="number" id="Total_Mileage" name="Total_Mileage" class="form-control" placeholder="Total Mileage (Km)">
                    </div>
                    <div class="mb-3">
                        <button type="reset" class="btn btn-primary" style="background-color: #1A120B; color: white;">Reset</button>
                        <button type="submit" name="save_tripData" class="btn btn-primary" style="background-color: #1A120B; color: white;">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showDateField() {
            var statusSelect = document.getElementById("CurrentStatus");
            var dateLabel = document.getElementById("dateLabel");

            if (statusSelect.value === "Order") {
                dateLabel.innerHTML = "Order Out Date";
            } else if (statusSelect.value === "Receiving") {
                dateLabel.innerHTML = "Received Date";
            }
        }
    </script>
</body>
</html>
