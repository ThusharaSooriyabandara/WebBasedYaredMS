<?php
    session_start();
    

 // Vehicle CRUD Database Connection
$con_vehicle = mysqli_connect("localhost", "root", "", "admin_database");

if (!$con_vehicle) {
    die('Vehicle CRUD Connection Failed' . mysqli_connect_error());
}

// Fetch data from the database for Vehicle CRUD
$vehicle_query = "SELECT status, COUNT(*) as Count FROM vehicle_details GROUP BY status";
$vehicle_result = mysqli_query($con_vehicle, $vehicle_query);

$vehicle_statusData = [];
while ($row = mysqli_fetch_assoc($vehicle_result)) {
    $vehicle_statusData[$row['status']] = $row['Count'];
}

// Fetch data from the database for Vehicle Status Distribution
$status_query = "SELECT status, COUNT(*) as count FROM vehicle_details GROUP BY status";
$status_result = mysqli_query($con_vehicle, $status_query);

$statusLabels = [];
$statusCounts = [];
while ($status_row = mysqli_fetch_assoc($status_result)) {
    $statusLabels[] = $status_row['status'];
    $statusCounts[] = $status_row['count'];
}
// Fetch data from the database for Assigned Vehicle Distribution
$assigned_query = "SELECT Assigned_Vehicle_Reg_No, COUNT(*) as count FROM vehicle_assign GROUP BY Assigned_Vehicle_Reg_No";
$assigned_result = mysqli_query($con_vehicle, $assigned_query);

$assignedLabels = [];
$assignedCounts = [];
while ($assigned_row = mysqli_fetch_assoc($assigned_result)) {
    $assignedLabels[] = $assigned_row['Assigned_Vehicle_Reg_No'];
    $assignedCounts[] = $assigned_row['count'];
}
// Fetch data from the database for CurrentStatus distribution
$current_status_query = "SELECT CurrentStatus, COUNT(*) as count FROM vehicle_assign GROUP BY CurrentStatus";
$current_status_result = mysqli_query($con_vehicle, $current_status_query);

$currentStatusData = [];
while ($row = mysqli_fetch_assoc($current_status_result)) {
    $currentStatusData[] = [
        'status' => $row['CurrentStatus'],
        'count' => $row['count']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js CSS -->
    <link href="https://cdn.jsdelivr.net/npm/chart.js" rel="stylesheet">

    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <style>
        body {
          background-color: black;
          background-repeat: no-repeat;
          background-attachment: fixed;  
          background-size: cover;
          opacity: 0.9;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            margin-top: 40px;
            width: 75%;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #5D9C59;
            color: #fff;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }

        .card-body {
            min-height: 200px;
            min-width: 100%; /* Adjust the value as needed */
        }

        table {
            background-color: #fff;
        }

        .chart-container {
            position: relative;
            width: 100%;
            height: 200px;
        }

        .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }

        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .button-container {
            text-align: right;
        }

        .column {
            width: 100%; /* Set a percentage value that suits your design */
        }

body {
            font-family: Arial, sans-serif;
            background-color: black;
        }

        .menu-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            height: 100%;
            background-color: #333;
            color: #fff;
        }

        .menu-bar ul {
            list-style-type: none;
            padding: 0;
        }

        .menu-bar li {
            padding: 15px;
            border-bottom: 1px solid #555;
        }

        .menu-bar li a {
            color: #fff;
            text-decoration: none;
        }

        .menu-bar li a:hover {
            background-color: #555;
        }

        .content {
            margin-left: 220px; /* Adjust this value to create space for the menu bar */
            padding: 20px;
        }


    </style>

</head>
<body>

<div class="header">
                <img src="#" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="#"></a>
            <a href="#"></a>
            <a href="#"></a>
        </div>

</div>


<!-- Menu Bar -->
<div class="menu-bar">
    <ul>
        <a class="logo" href="#home">
        <img src="logo.png" alt="Logo">
    </a>
    <br>
    <br>
        <li><a href="dash board.php">Driver Details</a></li>
        <li><a href="new.php">Vehicle Details</a></li>
        <li><a href="/loginpage/first_main_page.php">Home</a></li>
        <li><a href="/loginpage/About.php">About</a></li>
        <li><a href="#vehicle-details">Contact</a></li>
    </ul>
</div>


<div class="container">
    <?php
    // Get the count of registered vehicles
    $count_query = "SELECT COUNT(*) as total FROM vehicle_details";
    $count_result = mysqli_query($con_vehicle, $count_query);
    $total_vehicles = 0;
    if ($count_result) {
        $total_vehicles = mysqli_fetch_assoc($count_result)['total'];
    }

    // Get the count of vehicles in running condition
    $running_query = "SELECT COUNT(*) as running_total FROM vehicle_details WHERE status = 'REPAIR COMPLETE'";
    $running_result = mysqli_query($con_vehicle, $running_query);
    $running_vehicles = 0;
    if ($running_result) {
        $running_vehicles = mysqli_fetch_assoc($running_result)['running_total'];
    }

    // Get the count of vehicles in "GARAGE(UNDER REPAIR)" status
    $garage_query = "SELECT COUNT(*) as garage_total FROM vehicle_details WHERE status = 'GARAGE(UNDER REPAIR)'";
    $garage_result = mysqli_query($con_vehicle, $garage_query);
    $garage_vehicles = 0;
    if ($garage_result) {
        $garage_vehicles = mysqli_fetch_assoc($garage_result)['garage_total'];
    }

    // Get the count of vehicles in "Not in Use" status
    $not_in_use_query = "SELECT COUNT(*) as not_in_use_total FROM vehicle_details WHERE status = 'Not in Use'";
    $not_in_use_result = mysqli_query($con_vehicle, $not_in_use_query);
    $not_in_use_vehicles = 0;
    if ($not_in_use_result) {
        $not_in_use_vehicles = mysqli_fetch_assoc($not_in_use_result)['not_in_use_total'];
    }
    ?>


    <div class="row row-cols-1 row-cols-md-2 g-4" style="padding-left: 220px;">
        <!-- Card for Total Vehicles -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Total Vehicles</h4>
                    <h5><?= $total_vehicles ?></h5>
                </div>
            </div>
        </div>

        <!-- Card for Vehicles in Running Condition -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Vehicles in Running Condition</h4>
                    <h5><?= $running_vehicles ?></h5>
                </div>
            </div>
        </div>

        <!-- Card for Vehicles in Repair -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Vehicles in Repair</h4>
                    <h5><?= $garage_vehicles ?></h5>
                </div>
            </div>
        </div>

        <!-- Card for Vehicles Not in Use -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Vehicles Not in Use</h4>
                    <h5><?= $not_in_use_vehicles ?></h5>
                </div>
            </div>
        </div>
    </div>
<br>
<br>

    <div class="d-flex justify-content-center chart-container-wrapper" style="padding-left: 220px;">

    <!-- Column Chart -->
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <!-- Vehicle Class Distribution Chart -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Vehicle Class Distribution</h4>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="vehicleClassChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>

    <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Responsible Owner Distribution</h4>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="ownerChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>

    <!-- Vehicle Status Distribution Chart -->
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <h4>Vehicle Status Distribution</h4>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="statusChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>
    <div class="row row-cols-1 row-cols-md-2 g-4" style="padding-left: 220px;">
<!-- Vehicle Assign Distribution Chart -->
<div class="col">
    <div class="card">
        <div class="card-header">
            <h4>Assigned Vehicle Distribution</h4>
        </div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="assignedVehicleChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>
</div>
<!-- Vehicle Current Status Distribution Chart -->
<div class="col">
    <div class="card">
        <div class="card-header">
            <h4>Vehicle Current Status Distribution</h4>
        </div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="currentStatusChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>
</div>
</div>

    <!-- Chart.js Script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Vehicle Class Distribution Data
            var vehicleClassData = <?php
                $query_vehicle_class = "SELECT Vehicle_Class, COUNT(*) as count FROM vehicle_details GROUP BY Vehicle_Class";
                $query_vehicle_class_run = mysqli_query($con_vehicle, $query_vehicle_class);
                $vehicle_class_labels = [];
                $vehicle_class_counts = [];
                while ($vehicle_class = mysqli_fetch_assoc($query_vehicle_class_run)) {
                    $vehicle_class_labels[] = $vehicle_class['Vehicle_Class'];
                    $vehicle_class_counts[] = $vehicle_class['count'];
                }
                echo json_encode([
                    'labels' => $vehicle_class_labels,
                    'counts' => $vehicle_class_counts
                ]);
                ?>;

            // Vehicle Class Chart
            var ctxClass = document.getElementById('vehicleClassChart').getContext('2d');
            var vehicleClassChart = new Chart(ctxClass, {
                type: 'bar',
                data: {
                    labels: vehicleClassData.labels,
                    datasets: [{
                        label: 'Vehicle Class',
                        data: vehicleClassData.counts,
                        backgroundColor: 'rgba(255, 110, 49, 0.9)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Responsible Owner Distribution Data
            var ownerData = <?php
                $query_owner = "SELECT Responsible_Owner, COUNT(*) as count FROM vehicle_details GROUP BY Responsible_Owner";
                $query_owner_run = mysqli_query($con_vehicle, $query_owner);
                $owner_labels = [];
                $owner_counts = [];
                while ($owner = mysqli_fetch_assoc($query_owner_run)) {
                    $owner_labels[] = $owner['Responsible_Owner'];
                    $owner_counts[] = $owner['count'];
                }
                echo json_encode([
                    'labels' => $owner_labels,
                    'counts' => $owner_counts
                ]);
            ?>;
            var ctx = document.getElementById('ownerChart').getContext('2d');
            var ownerChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ownerData.labels,
                    datasets: [{
                        label: 'Responsible Owner',
                        data: ownerData.counts,
                        backgroundColor: [
                            'rgba(255, 110, 49, 0.9)',   // FF6E31 color
                            'rgba(26, 18, 11, 1)'      // 1A120B color
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });

            // Vehicle Status Distribution Data
            var statusData = <?php echo json_encode($statusCounts, JSON_NUMERIC_CHECK); ?>;
            var statusLabels = <?php echo json_encode($statusLabels); ?>;

            var ctxStatus = document.getElementById("statusChart").getContext("2d");
            new Chart(ctxStatus, {
                type: "bar",
                data: {
                    labels: statusLabels,
                    datasets: [{
                        label: "Vehicle Status",
                        data: statusData,
                        backgroundColor: ["#5D9C59", "#FF6E31", "#1A120B"],
                        borderColor: "#fff"
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js Script -->
<script>
    // ... Rest of the existing Chart.js code ...

    // Assigned Vehicle Distribution Data
    var assignedData = <?php echo json_encode($assignedCounts, JSON_NUMERIC_CHECK); ?>;
    var assignedLabels = <?php echo json_encode($assignedLabels); ?>;

    var ctxAssigned = document.getElementById("assignedVehicleChart").getContext("2d");
    new Chart(ctxAssigned, {
        type: "bar",
        data: {
            labels: assignedLabels,
            datasets: [{
                label: "Assigned Vehicle Distribution",
                data: assignedData,
                backgroundColor: "#FF6E31",
                borderColor: "#fff"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });</script>
    <!-- Chart.js Script (Add the following script at the end of the page) -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Current Status Distribution Data
        var currentStatusData = <?php echo json_encode($currentStatusData); ?>;
        var currentStatusLabels = currentStatusData.map(item => item.status);
        var currentStatusCounts = currentStatusData.map(item => item.count);

        var ctxCurrentStatus = document.getElementById("currentStatusChart").getContext("2d");
        new Chart(ctxCurrentStatus, {
            type: "pie",
            data: {
                labels: currentStatusLabels,
                datasets: [{
                    label: "Current Status",
                    data: currentStatusCounts,
                    backgroundColor: ["#5D9C59", "#FF6E31", "#1A120B", "#007BFF", "#6610F2"],
                    borderColor: "#fff"
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    });
</script>

</body>
</html>


