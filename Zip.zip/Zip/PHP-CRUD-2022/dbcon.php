<?php

$con = mysqli_connect("localhost","root","","admin_database");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>