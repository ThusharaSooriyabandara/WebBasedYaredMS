<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_gatein']))
{
    $gatein_id = mysqli_real_escape_string($con, $_POST['delete_gatein']);

    $query = "DELETE FROM gatein
 WHERE id='$gatein_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_gatein']))
{
    $gatein_id = mysqli_real_escape_string($con, $_POST['gatein_id']);

    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $GateIn_Time = mysqli_real_escape_string($con, $_POST['GateIn_Time']);
    

    $query = "UPDATE gatein
 SET Vehicle_Reg_No='$Vehicle_Reg_No', DriverName='$DriverName', GateIn_Time='$GateIn_Time' WHERE id='$gatein_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Updated";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['save_gatein']))
{
    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $GateIn_Time = mysqli_real_escape_string($con, $_POST['GateIn_Time']);
   

    $query = "INSERT INTO gatein
    (Vehicle_Reg_No,DriverName, GateIn_Time) VALUES ('$Vehicle_Reg_No', '$DriverName', '$GateIn_Time')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Created Successfully";
        header("Location: GateIn-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Created";
        header("Location: GateIn-create.php");
        exit(0);
    }
}
?>
