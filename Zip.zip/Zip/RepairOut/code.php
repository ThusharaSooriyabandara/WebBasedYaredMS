<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_repairOut']))
{
    $repairOut_id = mysqli_real_escape_string($con, $_POST['delete_repairOut']);

    $query = "DELETE FROM repair_out
 WHERE id='$repairOut_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_repairOut']))
{
    $repairOut_id = mysqli_real_escape_string($con, $_POST['repairOut_id']);

    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $Date_Time = mysqli_real_escape_string($con, $_POST['Date_Time']);
    $Driver_Name = mysqli_real_escape_string($con, $_POST['Driver_Name']);
    $TP_No = mysqli_real_escape_string($con, $_POST['TP_No']);
    $Repair_Type = mysqli_real_escape_string($con, $_POST['Repair_Type']);
    $Cost = mysqli_real_escape_string($con, $_POST['Cost']);
    $Additional_Notes = mysqli_real_escape_string($con, $_POST['Additional_Notes']);

    $query = "UPDATE repair_out
 SET Vehicle_Reg_No='$Vehicle_Reg_No', Date_Time='$Date_Time', Driver_Name='$Driver_Name', TP_No='$TP_No' Repair_Type='$Repair_Type', Cost='$Cost',Additional_Notes='$Additional_Notes' WHERE id='$repairOut_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: index.php");

        // Update admin_database, vehicle_details status column
        $update_status_query = "UPDATE admin_database.vehicle_details SET status='REPAIR COMPLETE' WHERE Registration_Number='$Vehicle_Reg_No'";
        mysqli_query($con, $update_status_query);


        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Updated";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['save_repairOut']))
{
    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $Date_Time = mysqli_real_escape_string($con, $_POST['Date_Time']);
    $Driver_Name = mysqli_real_escape_string($con, $_POST['Driver_Name']);
    $TP_No = mysqli_real_escape_string($con, $_POST['TP_No']);
    $Repair_type = mysqli_real_escape_string($con, $_POST['Repair_Type']);
    $Cost = mysqli_real_escape_string($con, $_POST['Cost']);
    $Additional_Notes = mysqli_real_escape_string($con, $_POST['Additional_Notes']);

    $query = "INSERT INTO repair_out
    (Vehicle_Reg_No, Date_Time, Driver_Name, TP_No, Repair_type, Cost, Additional_Notes) VALUES ('$Vehicle_Reg_No', '$Date_Time', '$Driver_Name', '$TP_No', '$Repair_Type', '$Cost', '$Additional_Notes')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Created Successfully";
        header("Location: repairOut-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Created";
        header("Location: repairOut-create.php");
        exit(0);
    }
}
?>
