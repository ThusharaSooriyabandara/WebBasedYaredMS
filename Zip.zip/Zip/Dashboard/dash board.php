<?php
    session_start();
    


// Driver CRUD Database Connection
$con_driver = mysqli_connect("localhost", "root", "", "admin_database");

if (!$con_driver) {
    die('Driver CRUD Connection Failed' . mysqli_connect_error());
}
    // GC Database Connection
    $con_gc = mysqli_connect("localhost", "root", "", "gc_database");
    if (!$con_gc) {
        die('GC Database Connection Failed' . mysqli_connect_error());
    }



    // Fetch data from the database
    $query = "SELECT CurrentStatus, COUNT(*) as Count FROM driverdetails GROUP BY CurrentStatus";
    $result = mysqli_query($con_driver, $query);

    $currentStatusData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $currentStatusData[$row['CurrentStatus']] = $row['Count'];
    }


    // Fetch data from the database for Driver CRUD
$driver_query = "SELECT CurrentStatus, COUNT(*) as Count FROM driverdetails GROUP BY CurrentStatus";
$driver_result = mysqli_query($con_driver, $driver_query);

$driver_CurrentStatusData = [];
while ($row = mysqli_fetch_assoc($driver_result)) {
    $driver_CurrentStatusData[$row['CurrentStatus']] = $row['Count'];
}


// Fetch data from the database for Driver CRUD
$driver_query = "SELECT CurrentStatus, COUNT(*) as Count FROM driverdetails GROUP BY CurrentStatus";
$driver_result = mysqli_query($con_driver, $driver_query);

$driver_statusData = []; // Initialize the array to store driver status counts

while ($row = mysqli_fetch_assoc($driver_result)) {
    $driver_statusData[$row['CurrentStatus']] = $row['Count'];
}

// Calculate the count of drivers who are Off Duty, On Duty, and Driving
$off_duty_drivers = isset($driver_statusData['Off Duty']) ? $driver_statusData['Off Duty'] : 0;
$on_duty_drivers = isset($driver_statusData['On Duty']) ? $driver_statusData['On Duty'] : 0;
$driving_drivers = isset($driver_statusData['Driving']) ? $driver_statusData['Driving'] : 0;

    // Fetch data from the database for GateIn_Time line chart
    $gatein_query = "SELECT DriverName, GateIn_Time FROM gatein";
    $gatein_result = mysqli_query($con_gc, $gatein_query);

    $gatein_data = [];
    while ($row = mysqli_fetch_assoc($gatein_result)) {
        $gatein_data[$row['DriverName']][] = $row['GateIn_Time'];
    }
    // Fetch data from the database for gateout_Time line chart
    $gateout_query = "SELECT DriverName, gateout_Time FROM gateout";
    $gateout_result = mysqli_query($con_gc, $gateout_query);

    $gateout_data = [];
    while ($row = mysqli_fetch_assoc($gateout_result)) {
        $gateout_data[$row['DriverName']][] = $row['gateout_Time'];
    }
// Get the total number of drivers
$total_drivers = array_sum($driver_CurrentStatusData);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js CSS -->
    <link href="https://cdn.jsdelivr.net/npm/chart.js" rel="stylesheet">

    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <style>
body {
          background-color: black;
          background-repeat: no-repeat;
          background-attachment: fixed;  
          background-size: cover;
          opacity: 0.9;
        }
       
        
        .container {
            margin-top: 40px;
            width: 75%;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #5D9C59;
            color: #fff;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }

        .card-body {
            min-height: 200px;
            min-width: 100%; /* Adjust the value as needed */
        }

        table {
            background-color: #fff;
        }

        .chart-container {
            position: relative;
            width: 100%;
            height: 200px;
        }

        .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }

        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }

        .button-container {
            text-align: right;
        }

        .column {
            width: 100%; /* Set a percentage value that suits your design */
        }

body {
            font-family: Arial, sans-serif;
            background-color: black;
        }

        .menu-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            height: 100%;
            background-color: #333;
            color: #fff;
        }

        .menu-bar ul {
            list-style-type: none;
            padding: 0;
        }

        .menu-bar li {
            padding: 15px;
            border-bottom: 1px solid #555;
        }

        .menu-bar li a {
            color: #fff;
            text-decoration: none;
        }

        .menu-bar li a:hover {
            background-color: #555;
        }

        .content {
            margin-left: 220px; /* Adjust this value to create space for the menu bar */
            padding: 20px;
        }

     .off-duty {
            background-color: #FF0000; /* Change the background color to your desired highlight color */
            color: #000; /* Change the text color to ensure readability */
            font-weight: bold;
        }
    .on-duty {
        background-color: #FFFF00; /* Change the background color to your desired highlight color for On Duty drivers */
        color: #000; /* Change the text color to ensure readability */
        font-weight: bold;
    }
    </style>

</head>
<body>

<div class="header">
                <img src="#" alt="Logo"></a>
                    <div class="nav-links">
                            <a href="#"></a>
                            <a href="#"></a>
                            <a href="#"></a>
                    </div>

</div>


<!-- Menu Bar -->
<div class="menu-bar">
    <ul>
        <a class="logo" href="#home">
        <img src="logo.png" alt="Logo"> </a>
    <br>
    <br>
        <li><a href="dash board.php">Driver Details</a></li>
        <li><a href="new.php">Vehicle Details</a></li>
        <li><a href="/loginpage/first_main_page.php">Home</a></li>
        <li><a href="/loginpage/About.php">About</a></li>
        <li><a href="#vehicle-details">Contact</a></li>
    </ul>
</div>

<div class="container">

    <div class="header-content">
        

            <div class="row row-cols-1 row-cols-md-2 g-4" style="padding-left: 220px;">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Total Drivers</h4>
                                <h5><?= $total_drivers ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Drivers Off Duty</h4>
                                <h5><?= isset($driver_statusData['Off Duty']) ? $driver_statusData['Off Duty'] : 0 ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Drivers On Duty</h4>
                                <h5><?= isset($driver_statusData['On Duty']) ? $driver_statusData['On Duty'] : 0 ?></h5>
                            </div>    
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Drivers Driving</h4>
                                <h5><?= isset($driver_statusData['Driving']) ? $driver_statusData['Driving'] : 0 ?></h5>
                            </div>
                        </div>
                    </div>
            </div>
<br>
<br>
            <div class="row row-cols-1 row-cols-md-2 g-4" style="padding-left: 220px;">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Driver Details</h4>
                            </div>
                            <div class="card-body">
                                <canvas id="currentStatusChart" width="400" height="200"></canvas>
                            </div>
                        </div>
   
                    </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            <h4>GateIn Time Line Chart</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="gateInTimeChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <br>
    <br>

            <div class="row row-cols-1 row-cols-md-2 g-4" style="padding-left: 220px;">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <h4>Driver Name List</h4>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered" id="driverNameList">
                                        <thead>
                                                <tr>
                                                    <th>Driver Name</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                    <?php
                                                    // Fetch driver names and status from the database
                                                    $driver_list_query = "SELECT DriverName, CurrentStatus FROM driverdetails";
                                                    $driver_list_result = mysqli_query($con_driver, $driver_list_query);

                                                    // Loop through each row and populate the table rows
                                                    while ($row = mysqli_fetch_assoc($driver_list_result)) {
                                                        $driver_name = $row['DriverName'];
                                                        $driver_status = $row['CurrentStatus'];
        // Check if the driver is ON duty and add the appropriate class
        $on_duty_class = $driver_status === 'On Duty' ? 'on-duty' : '';
                                                        // Check if the driver is OFF duty and add the appropriate class
                                        $off_duty_class = $driver_status === 'Off Duty' ? 'off-duty' : '';
                                                    ?>
        <tr class="<?php echo $on_duty_class . ' ' . $off_duty_class; ?>">
            <td><?php echo $driver_name; ?></td>
            <td><?php echo $driver_status; ?></td>
        </tr>
                                    <?php
                                    }
                                    ?>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                        <div class="card-header">
                                <h4>Gateout Time by Driver</h4>
                        </div>
                        <div class="card-body">
                        <canvas id="gateoutTimeChart" width="400" height="200"></canvas>
                        </div>
                    </div>
            </div>
        </div>
    
<script>
document.addEventListener("DOMContentLoaded", function() {
    var statusData = <?php echo json_encode($statusCounts, JSON_NUMERIC_CHECK); ?>;
    var statusLabels = <?php echo json_encode($statusLabels); ?>;
    
    var ctxStatus = document.getElementById("statusChart").getContext("2d");
    new Chart(ctxStatus, {
        type: "bar",
        data: {
            labels: statusLabels,
            datasets: [{
                label: "Vehicle Status",
                data: statusData,
                backgroundColor: ["#5D9C59", "#FF6E31", "#1A120B"],
                borderColor: "#fff"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0"></script>
<script>
        document.addEventListener("DOMContentLoaded", function() {
            var currentStatusData = <?php echo json_encode($currentStatusData, JSON_NUMERIC_CHECK); ?>;
            var currentStatusLabels = Object.keys(currentStatusData);
            var currentStatusValues = Object.values(currentStatusData);

            var ctx = document.getElementById("currentStatusChart").getContext("2d");
            new Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: currentStatusLabels,
                    datasets: [{
                        data: currentStatusValues,
                        backgroundColor: ["#5D9C59", "#FF6E31", "#1A120B"],
                        borderColor: "#fff"
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: "bottom"
                        }
                    }
                }
            });
        });
</script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Prepare data for the GateIn_Time line chart
            var gateinData = <?php echo json_encode($gatein_data); ?>;
            var gateinLabels = Object.keys(gateinData);
            var gateinTimes = Object.values(gateinData);

            // Calculate the average GateIn_Time for each driver
            var averageGateInTimes = [];
            for (const times of gateinTimes) {
                var total = 0;
                for (const time of times) {
                    total += parseFloat(time);
                }
                var average = total / times.length;
                averageGateInTimes.push(average.toFixed(2));
            }

            var ctxGateInTime = document.getElementById("gateInTimeChart").getContext("2d");
            new Chart(ctxGateInTime, {
                type: "line",
                data: {
                    labels: gateinLabels,
                    datasets: [{
                        label: "Average GateIn_Time",
                        data: averageGateInTimes,
                        borderColor: "#5D9C59",
                        backgroundColor: "rgba(93, 156, 89, 0.2)",
                        borderWidth: 2,
                        pointRadius: 5,
                        pointBackgroundColor: "#5D9C59",
                        pointBorderColor: "#fff",
                        pointHoverRadius: 7,
                        pointHoverBackgroundColor: "#5D9C59",
                        pointHoverBorderColor: "#fff",
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: "Average GateIn_Time",
                                font: {
                                    size: 14,
                                    weight: "bold"
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Prepare data for the GateIn_Time line chart
            var gateoutData = <?php echo json_encode($gateout_data); ?>;
            var gateoutLabels = Object.keys(gateoutData);
            var gateoutTimes = Object.values(gateoutData);

            // Calculate the average Gateout_Time for each driver
            var averagegateoutTimes = [];
            for (const times of gateoutTimes) {
                var total = 0;
                for (const time of times) {
                    total += parseFloat(time);
                }
                var average = total / times.length;
                averagegateoutTimes.push(average.toFixed(2));
            }

            var ctxgateoutTime = document.getElementById("gateoutTimeChart").getContext("2d");
            new Chart(ctxgateoutTime, {
                type: "line",
                data: {
                    labels: gateoutLabels,
                    datasets: [{
                        label: "Average gateout_Time",
                        data: averagegateoutTimes,
                        borderColor: "#FF6E31",
                        backgroundColor: "rgba(93, 156, 89, 0.2)",
                        borderWidth: 2,
                        pointRadius: 5,
                        pointBackgroundColor: "#FF6E31",
                        pointBorderColor: "#FF6E31",
                        pointHoverRadius: 7,
                        pointHoverBackgroundColor: "#5D9C59",
                        pointHoverBorderColor: "#FF6E31",
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: "Average gateout_Time",
                                font: {
                                    size: 14,
                                    weight: "bold"
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
   
   
</body>
</html>
