<?php
session_start();
require 'dbcon.php';
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Vehicle Edit</title>
</head>
<style>
    body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
.header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
</style>
<body>
        <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
  
    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="background-color: #FF6E31; color: black;">
                        <h4>Vehicle Edit 
                            <a href="index.php" class="btn btn-danger float-end" style="background-color: #1A120B; color: white;">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $vehicle_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM vehicle_details WHERE id='$vehicle_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $vehicle = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="vehicle_id" value="<?= $vehicle['id']; ?>">

                                    <div class="mb-3">
                                        <label for="Registration_Number" class="form-label">Registration Number</label>
                                        <input type="text" id="Registration_Number" name="Registration_Number" value="<?= $vehicle['Registration_Number']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Engine_Number" class="form-label">Engine Number</label>
                                        <input type="text" name="Engine_Number" value="<?= $vehicle['Engine_Number']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Chassis_No" class="form-label">Chassis Number</label>
                                        <input type="text" name="Chassis_No" value="<?= $vehicle['Chassis_No']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Vehicle_Class" class="form-label">Vehicle Class</label>
                                        <select id="Vehicle_Class" name="Vehicle_Class" class="form-select">
                                            <option value="Class 1" <?= $vehicle['Vehicle_Class'] == 'Class 1' ? 'selected' : ''; ?>>Class 1</option>
                                            <option value="Class 2" <?= $vehicle['Vehicle_Class'] == 'Class 2' ? 'selected' : ''; ?>>Class 2</option>
                                            <option value="Class 3" <?= $vehicle['Vehicle_Class'] == 'Class 3' ? 'selected' : ''; ?>>Class 3</option>
                                            <option value="Class 4" <?= $vehicle['Vehicle_Class'] == 'Class 4' ? 'selected' : ''; ?>>Class 4</option>
                                            <option value="Class 5" <?= $vehicle['Vehicle_Class'] == 'Class 5' ? 'selected' : ''; ?>>Class 5</option>
                                            <option value="Class 6" <?= $vehicle['Vehicle_Class'] == 'Class 6' ? 'selected' : ''; ?>>Class 6</option>
                                            <option value="Class 7" <?= $vehicle['Vehicle_Class'] == 'Class 7' ? 'selected' : ''; ?>>Class 7</option>
                                            <option value="Class 8" <?= $vehicle['Vehicle_Class'] == 'Class 8' ? 'selected' : ''; ?>>Class 8</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Taxation_Class" class="form-label">Taxation Class</label>
                                        <select id="Taxation_Class" name="Taxation_Class" class="form-select">
                                            <option value="6 Tyre Truck" <?= $vehicle['Taxation_Class'] == '6 Tyre Truck' ? 'selected' : ''; ?>>6 Tyre Truck</option>
                                            <option value="10 Tyre Multy Axie Truck" <?= $vehicle['Taxation_Class'] == '10 Tyre Multy Axie Truck' ? 'selected' : ''; ?>>10 Tyre Multy Axie Truck</option>
                                            <option value="12 Tyre Single Chassis Truck" <?= $vehicle['Taxation_Class'] == '12 Tyre Single Chassis Truck' ? 'selected' : ''; ?>>12 Tyre Single Chassis Truck</option>
                                            <option value="14 Tyre Single Chassis Rigid Truck" <?= $vehicle['Taxation_Class'] == '14 Tyre Single Chassis Rigid Truck' ? 'selected' : ''; ?>>14 Tyre Single Chassis Rigid Truck</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Make" class="form-label">Make</label>
                                        <select id="Make" name="Make" class="form-select">
                                            <option value="MACK" <?= $vehicle['Make'] == 'MACK' ? 'selected' : ''; ?>>MACK</option>
                                            <option value="Kenworth" <?= $vehicle['Make'] == 'Kenworth' ? 'selected' : ''; ?>>Kenworth</option>
                                            <option value="TATA" <?= $vehicle['Make'] == 'TATA' ? 'selected' : ''; ?>>TATA</option>
                                            <option value="Isuze" <?= $vehicle['Make'] == 'Isuze' ? 'selected' : ''; ?>>Isuze</option>
                                            <option value="MAZ-5440" <?= $vehicle['Make'] == 'MAZ-5440' ? 'selected' : ''; ?>>MAZ-5440</option>
                                            <option value="Foton" <?= $vehicle['Make'] == 'Foton' ? 'selected' : ''; ?>>Foton</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Type_of_body" class="form-label">Type of Body</label>
                                        <select id="Type_of_body" name="Type_of_body" class="form-select">
                                            <option value="Flatbed" <?= $vehicle['Type_of_body'] == 'Flatbed' ? 'selected' : ''; ?>>Flatbed</option>
                                            <option value="Van Body" <?= $vehicle['Type_of_body'] == 'Van Body' ? 'selected' : ''; ?>>Van Body</option>
                                            <option value="Dump Tipper" <?= $vehicle['Type_of_body'] == 'Dump Tipper' ? 'selected' : ''; ?>>Dump Tipper</option>
                                            <option value="Tanker" <?= $vehicle['Type_of_body'] == 'Tanker' ? 'selected' : ''; ?>>Tanker</option>
                                            <option value="Tractor" <?= $vehicle['Type_of_body'] == 'Tractor' ? 'selected' : ''; ?>>Tractor</option>
                                            <option value="Chassis Only" <?= $vehicle['Type_of_body'] == 'Chassis Only' ? 'selected' : ''; ?>>Chassis Only</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Color_1" class="form-label">Color 1</label>
                                        <input type="text" name="Color_1" value="<?= $vehicle['Color_1']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Color_2" class="form-label">Color 2</label>
                                        <input type="text" name="Color_2" value="<?= $vehicle['Color_2']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="fual_type" class="form-label">Fuel Type</label>
                                        <select id="fual_type" name="fual_type" class="form-select">
                                            <option value="Diesel" <?= $vehicle['fual_type'] == 'Diesel' ? 'selected' : ''; ?>>Diesel</option>
                                            <option value="Petrol" <?= $vehicle['fual_type'] == 'Petrol' ? 'selected' : ''; ?>>Petrol</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Cylinder_Capacity" class="form-label">Cylinder Capacity</label>
                                        <input type="text" name="Cylinder_Capacity" value="<?= $vehicle['Cylinder_Capacity']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="First_Registration" class="form-label">First Registration</label>
                                        <input type="date" name="First_Registration" value="<?= $vehicle['First_Registration']; ?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Responsible_Owner" class="form-label">Responsible Owner</label>
                                        <input type="text" name="Responsible_Owner" value="<?= $vehicle['Responsible_Owner']; ?>" class="form-control">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="Remarks" class="form-label">Remarks</label>
                                        <input type="text" name="Remarks" value="<?= $vehicle['Remarks']; ?>" class="form-control">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="Vehicle_Photo" class="form-label">Vehicle Photo</label>
                                        <input type="file" id="Vehicle_Photo" name="Vehicle_Photo" class="form-control" accept="image/*">
                                    </div>
                                                <div class="mb-3">
                                                        <label for="CurrentVehiclePhoto" class="form-label">Current Vehicle Photo</label>
                                                        <br>
                                                        <?php if(!empty($vehicle['Vehicle_Photo'])) { ?>
                                                            <img src="uploads/<?= $vehicle['Vehicle_Photo']; ?>" alt="Vehicle Photo" width="200">
                                                        <?php } else { ?>
                                                            <span>No photo available</span>
                                                        <?php } ?>
                                                </div>

                                    <div class="mb-3">
                                        <button type="submit" name="update_vehicle" class="btn btn-primary" style="background-color: #1A120B; color: white;">Update Vehicle</button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>