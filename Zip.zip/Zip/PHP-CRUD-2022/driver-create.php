<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Driver Create</title>
    <style>
body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
        .container {
            max-width: 600px;
            margin-top: 80px;

            }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;

        }
        .float-end {
            margin-left: auto;
        }
        .card-body {
            background-color: #fff;
            padding: 1rem;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-color: #ccc;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0069d9;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }

            .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
  
    <div class="container mt-5">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header" style="background-color: #5D9C59; color: black;">
                <h4>Driver Add</h4>
                <a href="index.php" class="btn btn-danger float-end" style="background-color: #1A120B; color: white;">View Driver Data</a>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data" onsubmit="return validateTPNo()">
                    <div class="mb-3">
                        <label for="DriverRegNo" class="form-label">Driver Reg. No.</label>
                        <input type="text" id="DriverRegNo" name="DriverRegNo" class="form-control" placeholder="Driver Registration Number" required>
                    </div>
                    <div class="mb-3">
                        <label for="DriverName" class="form-label">Driver Name</label>
                        <input type="text" id="DriverName" name="DriverName" class="form-control" placeholder="Driver Name" required>
                    </div>
                    <div class="mb-3">
                        <label for="LicenseNo" class="form-label">License No</label>
                        <input type="text" id="LicenseNo" name="LicenseNo" class="form-control" placeholder="License No" required>
                    </div>
                    <div class="mb-3">
                        <label for="NICNo" class="form-label">NIC No</label>
                        <input type="text" id="NICNo" name="NICNo" class="form-control" placeholder="NIC No" required>
                    </div>
                    <div class="mb-3">
                        <label for="TPNo" class="form-label">TP No</label>
                        <input type="text" id="TPNo" name="TPNo" class="form-control" placeholder="TP No" required>       
                    </div>
                    <div class="mb-3">
                        <label for="Address" class="form-label">Address</label>
                        <input type="text" id="Address" name="Address" class="form-control" placeholder="Address" required>       
                    </div>
                    <div class="mb-3">
                        <label for="CurrentStatus" class="form-label">Current Status</label>
                        <select id="CurrentStatus" name="CurrentStatus" class="form-select" required>
                            <option value="Off Duty">Off Duty</option>
                            <option value="On Duty">On Duty</option>
                            <option value="Driving">Driving</option>
                        </select>      
                    </div>
                    <div class="mb-3">
                        <label for="DriverPhoto" class="form-label">Driver Photo</label>
                        <input type="file" id="DriverPhoto" name="DriverPhoto" class="form-control" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <button type="reset" class="btn btn-primary" style="background-color: #1A120B; color: white;">Reset</button>
                        <button type="submit" name="save_driver" class="btn btn-primary" style="background-color: #1A120B; color: white;">Save</button>
                    </div>
                </form>
               
            </div>
        </div>
    </div>

    <script>
        function validateTPNo() {
            var tpNoInput = document.getElementById('TPNo');
            var tpNo = tpNoInput.value.trim();
            
            if (!tpNo.startsWith('+94')) {
                alert('TP No must start with "+94"');
                tpNoInput.focus();
                return false;
            }
            
            return true;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
