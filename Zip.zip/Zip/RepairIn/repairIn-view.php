<?php
require 'dbcon.php';
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Repair In Data View</title>
</head>
<style>
    body {
  background-image: url('vehicleOperatorMain.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
.header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .card-header {
            background-color: #6C3428;
            
        }
</style>
<body>
<div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
<body>

    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Repair In Data View Details 
                            <a href="index.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $repairIn_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM repair_in WHERE id='$repairIn_id'";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $repairIn = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code.php" method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="Vehicle_Reg_No" class="form-label">Vehicle Reg. No.</label>
                                        <input type="text" id="Vehicle_Reg_No" name="Vehicle_Reg_No" class="form-control" value="<?= $repairIn['Vehicle_Reg_No']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Date_Time" class="form-label">Repair in Date & Time</label>
                                        <input type="text" id="Date_Time" name="Date_Time" class="form-control" value="<?= $repairIn['Date_Time']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Current_Driver_Name" class="form-label">Current Driver Name</label>
                                        <input type="text" id="Current_Driver_Name" name="Current_Driver_Name" class="form-control" value="<?= $repairIn['Current_Driver_Name']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="TP_No" class="form-label">TP No</label>
                                        <input type="text" id="TP_No" name="TP_No" class="form-control" value="<?= $repairIn['TP_No']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Mileage" class="form-label">Current Mileage</label>
                                        <input type="text" id="Mileage" name="Mileage" class="form-control" value="<?= $repairIn['Mileage']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Issue" class="form-label">Issue</label>
                                        <input type="text" id="Issue" name="Issue" class="form-control" value="<?= $repairIn['Issue']; ?>" readonly>
                                    </div>
                                   
                                    <div class="mb-3">
                                        <label for="Previous" class="form-label">Previous Repair Maintenance</label>
                                        <input type="text" id="Previous" name="Previous" class="form-control" value="<?= $repairIn['Previous']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Cost" class="form-label">Estimate Cost</label>
                                        <input type="text" id="Cost" name="Cost" class="form-control" value="<?= $repairIn['Cost']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Repair_Timeline" class="form-label">Repair Timeline</label>
                                        <input type="text" id="Repair_Timeline" name="Repair_Timeline" class="form-control" value="<?= $repairIn['Repair_Timeline']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Additional_Notes" class="form-label">Additional Notes</label>
                                        <input type="text" id="Additional_Notes" name="Additional_Notes" class="form-control" value="<?= $repairIn['Additional_Notes']; ?>" readonly>
                                    </div>
                                   
                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such ID Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
