<?php

$con = mysqli_connect("localhost","root","","gc_database");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>