<?php
require 'dbcon.php';
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Vehicle View</title>
</head>
<style>
    body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
.header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
</style>
<body>
        <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
    <div class="container mt-5">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="background-color: #FF6E31; color: black;">
                        <h4>Vehicle View Details 
                            <a href="index.php" class="btn btn-danger float-end" style="background-color: #1A120B; color: white;">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $vehicle_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM vehicle_details WHERE id='$vehicle_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $vehicle = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code.php" method="POST" enctype="multipart/form-data">
                                   <div class="mb-3">
                                         
                                        <img src="uploads/<?= $vehicle['Vehicle_Photo']; ?>" alt="Vehicle Photo" class="img-thumbnail" width="200">
                                    </div>
                                    <div class="mb-3">
                                        <label for="Registration_Number" class="form-label">Registration Number</label>
                                        <input type="text" id="Registration_Number" name="Registration_Number" class="form-control" value="<?=$vehicle['Registration_Number']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Engine_Number" class="form-label">Engine Number</label>
                                        <input type="text" id="Engine_Number" name="Engine_Number" class="form-control" value="<?=$vehicle['Engine_Number']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Chassis_No" class="form-label">Chassis Number</label>
                                        <input type="text" id="Chassis_No" name="Chassis_No" class="form-control" value="<?=$vehicle['Chassis_No']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Vehicle_Class" class="form-label">Vehicle Class</label>
                                        <input type="text" id="Vehicle_Class" name="Vehicle_Class" class="form-control" value="<?=$vehicle['Vehicle_Class']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Taxation_Class" class="form-label">Taxation Class</label>
                                        <input type="text" id="Taxation_Class" name="Taxation_Class" class="form-control" value="<?=$vehicle['Taxation_Class']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Make" class="form-label">Make</label>
                                        <input type="text" id="Make" name="Make" class="form-control" value="<?=$vehicle['Make']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Type_of_body" class="form-label">Type of Body</label>
                                        <input type="text" id="Type_of_body" name="Type_of_body" class="form-control" value="<?=$vehicle['Type_of_body']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Color_1" class="form-label">Color 1</label>
                                        <input type="text" id="Color_1" name="Color_1" class="form-control" value="<?=$vehicle['Color_1']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Color_2" class="form-label">Color 2</label>
                                        <input type="text" id="Color_2" name="Color_2" class="form-control" value="<?=$vehicle['Color_2']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="fual_type" class="form-label">Fuel Type</label>
                                        <input type="text" id="fual_type" name="fual_type" class="form-control" value="<?=$vehicle['fual_type']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Cylinder_Capacity" class="form-label">Cylinder Capacity</label>
                                        <input type="text" id="Cylinder_Capacity" name="Cylinder_Capacity" class="form-control" value="<?=$vehicle['Cylinder_Capacity']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="First_Registration" class="form-label">First Registration</label>
                                        <input type="text" id="First_Registration" name="First_Registration" class="form-control" value="<?=$vehicle['First_Registration']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Responsible_Owner" class="form-label">Responsible Owner</label>
                                        <input type="text" id="Responsible_Owner" name="Responsible_Owner" class="form-control" value="<?=$vehicle['Responsible_Owner']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="status" class="form-label">Current Status</label>
                                        <input type="text" id="status" name="status" class="form-control" value="<?=$vehicle['status']; ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="Remarks" class="form-label">Remarks</label>
                                        <input type="text" id="Remarks" name="Remarks" class="form-control" value="<?=$vehicle['Remarks']; ?>" readonly>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
