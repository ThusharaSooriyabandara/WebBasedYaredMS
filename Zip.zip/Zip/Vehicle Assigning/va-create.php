<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Vehicle Assign</title>
    <style>
body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        .float-end {
            margin-left: auto;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-color: #ccc;
        }
        .btn-primary {
            background-color: #1A120B;
            border-color: #1A120B;
        }
        .btn-primary:hover {
            background-color: #1A120B;
            border-color: #1A120B;
        }
 .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
    </style>
</head>
<script>
    // Function to fetch driver name based on driver registration number
    function fetchDriverName() {
        var driverRegNo = document.getElementById('DriverRegNo').value;

        // Make an AJAX request to get the driver name
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_driver_name.php');
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    document.getElementById('DriverName').value = response.driverName;
                } else {
                    document.getElementById('DriverName').value = '';
                }
            }
        };
        xhr.send('driverRegNo=' + encodeURIComponent(driverRegNo));
    }
</script>
<body>
      <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div>
    <div class="container mt-5">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header">
                <h4>Vehicle Assign</h4>
                <a href="index.php" class="btn btn-danger float-end">BACK</a>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">
<div class="mb-3">
    <label for="DriverRegNo" class="form-label">Driver Reg. No.</label>
    <input type="text" id="DriverRegNo" name="DriverRegNo" class="form-control" placeholder="Driver Registration Number" required onblur="fetchDriverName()">
</div>

                    <div class="mb-3">
                        <label for="DriverName" class="form-label">Driver Name</label>
                        <input type="text" id="DriverName" name="DriverName" class="form-control" placeholder="Driver Name" required>
                    </div>
                    <div class="mb-3">
                        <label for="AssignedVehicleRegNo" class="form-label">Assigned Vehicle Reg. No.</label>
                        <input type="text" id="Assigned_Vehicle_Reg_No" name="Assigned_Vehicle_Reg_No" class="form-control" placeholder="Assigned Vehicle Reg. No." required>
                    </div>
                    <div class="mb-3">
                        <label for="CurrentStatus" class="form-label">Status</label>
                        <select id="CurrentStatus" name="CurrentStatus" class="form-select" required>
                            <option value="Order">Order</option>
                            <option value="Receiving">Receiving</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="TripID" class="form-label">Trip ID</label>
                        <input type="number" id="Trip_ID" name="Trip_ID" class="form-control" placeholder="Trip ID" required>
                    </div>
                    <div class="mb-3">
                        <label for="TripStartDate" class="form-label">Trip Start Date</label>
                        <input type="datetime-local" id="Trip_Start_Date" name="Trip_Start_Date" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="TripEndDate" class="form-label">Trip End Date</label>
                        <input type="datetime-local" id="Trip_End_Date" name="Trip_End_Date" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <button type="reset" class="btn btn-primary">Reset</button>
                        <button type="submit" name="save_vAssign" class="btn btn-primary">Save</button>
                    </div>
                </form>
               
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
