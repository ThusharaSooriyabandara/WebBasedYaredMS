<?php
session_start();
require 'dbcon.php';

if (isset($_POST['delete_vehicle'])) {
    $vehicle_id = mysqli_real_escape_string($con, $_POST['delete_vehicle']);

    $query = "DELETE FROM vehicle_details WHERE id='$vehicle_id' ";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        $_SESSION['message'] = "vehicle Deleted Successfully";
        header("Location: index.php");
        exit(0);
    } else {
        $_SESSION['message'] = "vehicle Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if (isset($_POST['update_vehicle'])) {
    $vehicle_id = mysqli_real_escape_string($con, $_POST['vehicle_id']);

    $Registration_Number = mysqli_real_escape_string($con, $_POST['Registration_Number']);
    $Engine_Number = mysqli_real_escape_string($con, $_POST['Engine_Number']);
    $Chassis_No = mysqli_real_escape_string($con, $_POST['Chassis_No']);
    $Vehicle_Class = mysqli_real_escape_string($con, $_POST['Vehicle_Class']);
    $Taxation_Class = mysqli_real_escape_string($con, $_POST['Taxation_Class']);
    $Make = mysqli_real_escape_string($con, $_POST['Make']);
    $Type_of_body = mysqli_real_escape_string($con, $_POST['Type_of_body']);
    $Color_1 = mysqli_real_escape_string($con, $_POST['Color_1']);
    $Color_2 = mysqli_real_escape_string($con, $_POST['Color_2']);
    $fual_type = mysqli_real_escape_string($con, $_POST['fual_type']);
    $Cylinder_Capacity = mysqli_real_escape_string($con, $_POST['Cylinder_Capacity']);
    $First_Registration = mysqli_real_escape_string($con, $_POST['First_Registration']);
    $Responsible_Owner = mysqli_real_escape_string($con, $_POST['Responsible_Owner']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    $Remarks = mysqli_real_escape_string($con, $_POST['Remarks']);
    $Vehicle_Photo = mysqli_real_escape_string($con, $_POST['Vehicle_Photo']);

    // Handle file upload
    if (isset($_FILES['Vehicle_Photo']['name'])) {
        $file_name = $_FILES['Vehicle_Photo']['name'];
        $file_size = $_FILES['Vehicle_Photo']['size'];
        $file_tmp = $_FILES['Vehicle_Photo']['tmp_name'];
        $file_type = $_FILES['Vehicle_Photo']['type'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $extensions = array("jpg", "jpeg", "png");

        if (in_array($file_ext, $extensions) === false) {
            $_SESSION['message'] = "Invalid file extension. Only JPG, JPEG, and PNG files are allowed.";
            header("Location: index.php");
            exit(0);
        }

        // Move uploaded file to a directory (e.g., "uploads/")
        $upload_dir = "uploads/";
        $new_file_name = uniqid('vehicle_') . '.' . $file_ext;
        move_uploaded_file($file_tmp, $upload_dir . $new_file_name);

        // Update the database with the file name
        $query = "UPDATE vehicle_details SET 
            Registration_Number='$Registration_Number',
            Engine_Number='$Engine_Number',
            Chassis_No='$Chassis_No',
            Vehicle_Class='$Vehicle_Class',
            Taxation_Class='$Taxation_Class',
            Make='$Make',
            Type_of_body='$Type_of_body',
            Color_1='$Color_1',
            Color_2='$Color_2',
            fual_type='$fual_type',
            Cylinder_Capacity='$Cylinder_Capacity',
            First_Registration='$First_Registration',
            Responsible_Owner='$Responsible_Owner',
            status='$status',
            Remarks='$Remarks',
            Vehicle_Photo='$new_file_name'
        WHERE id='$vehicle_id' ";
    } else {
        // Update the database without the file name
        $query = "UPDATE vehicle_details SET 
            Registration_Number='$Registration_Number',
            Engine_Number='$Engine_Number',
            Chassis_No='$Chassis_No',
            Vehicle_Class='$Vehicle_Class',
            Taxation_Class='$Taxation_Class',
            Make='$Make',
            Type_of_body='$Type_of_body',
            Color_1='$Color_1',
            Color_2='$Color_2',
            fual_type='$fual_type',
            Cylinder_Capacity='$Cylinder_Capacity',
            First_Registration='$First_Registration',
            Responsible_Owner='$Responsible_Owner',
            status='$status',
            Remarks='$Remarks'
            Vehicle_Photo='$new_file_name'
        WHERE id='$vehicle_id' ";
    }

    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        $_SESSION['message'] = "vehicle Updated Successfully";
        header("Location: index.php");
        exit(0);
    } else {
        $_SESSION['message'] = "vehicle Not Updated";
        header("Location: index.php");
        exit(0);
    }
}


if (isset($_POST['save_vehicle'])) {
    $Registration_Number = mysqli_real_escape_string($con, $_POST['Registration_Number']);
    $Engine_Number = mysqli_real_escape_string($con, $_POST['Engine_Number']);
    $Chassis_No = mysqli_real_escape_string($con, $_POST['Chassis_No']);
    $Vehicle_Class = mysqli_real_escape_string($con, $_POST['Vehicle_Class']);
    $Taxation_Class = mysqli_real_escape_string($con, $_POST['Taxation_Class']);
    $Make = mysqli_real_escape_string($con, $_POST['Make']);
    $Type_of_body = mysqli_real_escape_string($con, $_POST['Type_of_body']);
    $Color_1 = mysqli_real_escape_string($con, $_POST['Color_1']);
    $Color_2 = mysqli_real_escape_string($con, $_POST['Color_2']);
    $fual_type = mysqli_real_escape_string($con, $_POST['fual_type']);
    $Cylinder_Capacity = mysqli_real_escape_string($con, $_POST['Cylinder_Capacity']);
    $First_Registration = mysqli_real_escape_string($con, $_POST['First_Registration']);
    $Responsible_Owner = mysqli_real_escape_string($con, $_POST['Responsible_Owner']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    $Remarks = mysqli_real_escape_string($con, $_POST['Remarks']);
    $Vehicle_Photo = mysqli_real_escape_string($con, $_POST['Vehicle_Photo']);

    // Handle file upload
    if (isset($_FILES['Vehicle_Photo']['name'])) {
        $file_name = $_FILES['Vehicle_Photo']['name'];
        $file_size = $_FILES['Vehicle_Photo']['size'];
        $file_tmp = $_FILES['Vehicle_Photo']['tmp_name'];
        $file_type = $_FILES['Vehicle_Photo']['type'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $extensions = array("jpg", "jpeg", "png");

        if (in_array($file_ext, $extensions) === false) {
            $_SESSION['message'] = "Invalid file extension. Only JPG, JPEG, and PNG files are allowed.";
            header("Location: vr-create.php");
            exit(0);
        }

        // Move uploaded file to a directory (e.g., "uploads/")
        $upload_dir = "uploads/";
        $new_file_name = uniqid('vehicle_') . '.' . $file_ext;
        move_uploaded_file($file_tmp, $upload_dir . $new_file_name);

        // Insert the data into the database
        $query = "INSERT INTO vehicle_details (Registration_Number, Engine_Number, Chassis_No, Vehicle_Class, Taxation_Class, Make, Type_of_body, Color_1, Color_2, fual_type, Cylinder_Capacity, First_Registration, Responsible_Owner, status, Remarks, Vehicle_Photo)
        VALUES ('$Registration_Number','$Engine_Number','$Chassis_No','$Vehicle_Class','$Taxation_Class','$Make','$Type_of_body','$Color_1','$Color_2','$fual_type','$Cylinder_Capacity','$First_Registration','$Responsible_Owner','$status','$Remarks','$new_file_name')";
    } else {
        // Insert the data into the database without the file name
        $query = "INSERT INTO vehicle_details (Registration_Number, Engine_Number, Chassis_No, Vehicle_Class, Taxation_Class, Make, Type_of_body, Color_1, Color_2, fual_type, Cylinder_Capacity, First_Registration, Responsible_Owner, status, Remarks, Vehicle_Photo)
        VALUES ('$Registration_Number','$Engine_Number','$Chassis_No','$Vehicle_Class','$Taxation_Class','$Make','$Type_of_body','$Color_1','$Color_2','$fual_type','$Cylinder_Capacity','$First_Registration','$Responsible_Owner','$status','$Remarks', '$new_file_name')";
    }

    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        $_SESSION['message'] = "vehicle Created Successfully";
        header("Location: vr-create.php");
        exit(0);
    } else {
        $_SESSION['message'] = "vehicle Not Created";
        header("Location: vr-create.php");
        exit(0);
    }
}
?>
