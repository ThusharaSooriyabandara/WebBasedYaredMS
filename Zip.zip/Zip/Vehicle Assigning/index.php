<?php
    session_start();
    require 'dbcon.php';

    // Fetch count of orders and receivings from the database
    $query = "SELECT COUNT(*) AS count, CurrentStatus FROM vehicle_assign GROUP BY CurrentStatus";
    $result = mysqli_query($con, $query);
    $statusData = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $statusData[$row['CurrentStatus']] = $row['count'];
    }
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <title>Vehicle Assign</title>
</head>
<style>
    body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
 .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
</style>
<body>
      <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
    <div class="container mt-4">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Vehicle Assign Details
                            <a href="/loginpage/home.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Admin Home</a>
                            <a href="va-create.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Assign Vehicle</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Driver Reg. No.</th>
                                    <th>DriverName</th>
                                    <th>Assigned Vehicle Reg. No.</th>
                                    <th>Status</th>
                                    <th>Trip ID</th>
                                    <th>Trip Start Date</th>
                                    <th>Trip End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM vehicle_assign";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $vAssign)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $vAssign['id']; ?></td>
                                                <td><?= $vAssign['DriverRegNo']; ?></td>
                                                <td><?= $vAssign['DriverName']; ?></td>
                                                <td><?= $vAssign['Assigned_Vehicle_Reg_No']; ?></td>
                                                <td><?= $vAssign['CurrentStatus']; ?></td>
                                                <td><?= $vAssign['Trip_ID']; ?></td>
                                                <td><?= $vAssign['Trip_Start_Date']; ?></td>
                                                <td><?= $vAssign['Trip_End_Date']; ?></td>
                                            
                                                <td>
                                                    <a href="va-view.php?id=<?= $vAssign['id']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="va-edit.php?id=<?= $vAssign['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                                    <form action="code.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete_vAssign" value="<?=$vAssign['id'];?>" class="btn btn-danger btn-sm">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5>No Record Found</h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>
                        
                        <canvas id="statusChart"></canvas> <!-- Bar graph container -->

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Get status data from PHP using JSON
        var statusData = <?php echo json_encode($statusData); ?>;

        // Get status labels and counts
        var labels = Object.keys(statusData);
        var counts = Object.values(statusData);

        // Generate random colors for the bars
        var colors = labels.map(() => '#' + (Math.random().toString(16) + '000000').substring(2, 8));

        // Create a bar chart using Chart.js
        var statusChart = new Chart(document.getElementById('statusChart'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    data: counts,
                    backgroundColor: colors
                }]
            },
            options: {
                responsive: true,
                legend: { display: false },
                scales: {
                    xAxes: [{
                        ticks: { autoSkip: false }
                    }],
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            precision: 0
                        }
                    }]
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>