<?php
    session_start();
    require 'dbcon.php';


    // Fetch data from the database
    $query = "SELECT CurrentStatus, COUNT(*) as Count FROM driverdetails GROUP BY CurrentStatus";
    $result = mysqli_query($con, $query);

    $currentStatusData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $currentStatusData[$row['CurrentStatus']] = $row['Count'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Driver CRUD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <style>
body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 0.9;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            margin-top: 40px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #5D9C59;
            color: #fff;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }

        table {
            background-color: #fff;
        }
        
        .chart-container {
            position: relative;
            width: 100%;
            height: 200px;
        }
            .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
.button-container {
  text-align: right;
}
    </style>
</head>
<body>

    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="/loginpage/About.php">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 

    <div class="container">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header">
                <div class="logo">
                    <img src="logo.png" alt="Company Logo" height="150">
                </div>
                <h4>Driver Details</h4>
                <div class="search-bar">
                    <input type="text" class="form-control search-input" id="searchDriver" placeholder="Search Driver Name">
                </div>
                <div class="button-container">
    <a href="/loginpage/home.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Admin Home</a>
    <a href="driver-create.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Add Driver</a>
<!-- Update the download link -->
<a href="export index.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Download</a>
</div>
            
        </div>

        <div class="card-body">
            <div class="chart-container">
    <div class="chart-container" style="background-color: #f2f2f2;">

                <canvas id="currentStatusChart"></canvas>
            </div>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>DriverRegNo</th>
                        <th>DriverName</th>
                        <th>LicenseNo</th>
                        <th>NICNo</th>
                        <th>TPNo</th>
                        <th>Address</th>
                        <th>CurrentStatus</th>
                        <th>DriverPhoto</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $query = "SELECT * FROM driverdetails";
                        $query_run = mysqli_query($con, $query);

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            foreach($query_run as $driver)
                            {
                    ?>
                                <tr>
                                    <td><?= $driver['id']; ?></td>
                                    <td><?= $driver['DriverRegNo']; ?></td>
                                    <td><?= $driver['DriverName']; ?></td>
                                    <td><?= $driver['LicenseNo']; ?></td>
                                    <td><?= $driver['NICNo']; ?></td>
                                    <td><?= $driver['TPNo']; ?></td>
                                    <td><?= $driver['Address']; ?></td>
                                    <td><?= $driver['CurrentStatus']; ?></td>
                                     <td>
                                        <img src="uploads/<?= $driver['DriverPhoto']; ?>" alt="Driver Photo" width="100">
                                    </td>

                                    <td>
                                        <a href="driver-view.php?id=<?= $driver['id']; ?>" class="btn btn-info btn-sm" style="background-color: #1A120B; color: white;">View</a>
                                        <a href="driver-edit.php?id=<?= $driver['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                        <form action="code.php" method="POST" class="d-inline">
                                            
                                        </form>
                                    </td>
                                </tr>
                    <?php
                            }
                        }
                        else
                        {
                            echo "<tr><td colspan='10'><h5 class='text-center'>No Record Found</h5></td></tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.0"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var currentStatusData = <?php echo json_encode($currentStatusData, JSON_NUMERIC_CHECK); ?>;
            var currentStatusLabels = Object.keys(currentStatusData);
            var currentStatusValues = Object.values(currentStatusData);

            var ctx = document.getElementById("currentStatusChart").getContext("2d");
            new Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: currentStatusLabels,
                    datasets: [{
                        data: currentStatusValues,
                        backgroundColor: ["#5D9C59", "#FF6E31", "#1A120B"],
                        borderColor: "#fff"
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: "bottom"
                        }
                    }
                }
            });
        });

        // Driver Search Functionality
        document.getElementById('searchDriver').addEventListener('input', function() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById('searchDriver');
            filter = input.value.toUpperCase();
            table = document.getElementsByTagName('table')[0];
            tr = table.getElementsByTagName('tr');

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName('td')[2]; // Index 2 is the column of DriverName
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                    } else {
                        tr[i].style.display = 'none';
                    }
                }
            }
        });
    </script>
</body>
</html>
