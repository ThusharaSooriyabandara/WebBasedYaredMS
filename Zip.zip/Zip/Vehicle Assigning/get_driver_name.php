<?php
// get_driver_name.php

if (isset($_POST['driverRegNo'])) {
    $driverRegNo = $_POST['driverRegNo'];

    // Assuming you have the database connection setup in dbcon.php
    require 'dbcon.php';

    // Fetch the driver name based on the registration number from the driver_details table
    $query = "SELECT DriverName FROM admin_database.driverdetails WHERE DriverRegNo = '$driverRegNo'";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $driverName = $row['DriverName'];

        // Send the response as JSON
        echo json_encode(array('success' => true, 'driverName' => $driverName));
    } else {
        // Driver not found
        echo json_encode(array('success' => false));
    }

    // Close the database connection
    mysqli_close($con);
}
?>
