<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_repairIn']))
{
    $repairIn_id = mysqli_real_escape_string($con, $_POST['delete_repairIn']);

    $query = "DELETE FROM repair_in
 WHERE id='$repairIn_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_repairIn']))
{
    $repairIn_id = mysqli_real_escape_string($con, $_POST['repairIn_id']);

    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $Date_Time = mysqli_real_escape_string($con, $_POST['Date_Time']);
    $Current_Driver_Name = mysqli_real_escape_string($con, $_POST['Current_Driver_Name']);
    $TP_No = mysqli_real_escape_string($con, $_POST['TP_No']);
    $Mileage = mysqli_real_escape_string($con, $_POST['Mileage']);
    $Issue = mysqli_real_escape_string($con, $_POST['Issue']);
    
    $Previous = mysqli_real_escape_string($con, $_POST['Previous']);
    $Cost = mysqli_real_escape_string($con, $_POST['Cost']);
    $Repair_Timeline = mysqli_real_escape_string($con, $_POST['Repair_Timeline']);
    $Additional_Notes = mysqli_real_escape_string($con, $_POST['Additional_Notes']);

    $query = "UPDATE repair_in
 SET Vehicle_Reg_No='$Vehicle_Reg_No', Date_Time='$Date_Time', Current_Driver_Name='$Current_Driver_Name', TP_No='$TP_No' Mileage='$Mileage', Issue='$Issue', Previous='$Previous', Cost='$Cost', TP_No='$TP_No' Repair_Timeline='$Repair_Timeline', Additional_Notes='$Additional_Notes' WHERE id='$repairIn_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Updated";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['save_repairIn']))
{
    $Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Vehicle_Reg_No']);
    $Date_Time = mysqli_real_escape_string($con, $_POST['Date_Time']);
    $Current_Driver_Name = mysqli_real_escape_string($con, $_POST['Current_Driver_Name']);
    $TP_No = mysqli_real_escape_string($con, $_POST['TP_No']);
    $Mileage = mysqli_real_escape_string($con, $_POST['Mileage']);
    $Issue = mysqli_real_escape_string($con, $_POST['Issue']);
    $Current_Status = mysqli_real_escape_string($con, $_POST['Current_Status']);
    $Previous = mysqli_real_escape_string($con, $_POST['Previous']);
    $Cost = mysqli_real_escape_string($con, $_POST['Cost']);
    $Repair_Timeline = mysqli_real_escape_string($con, $_POST['Repair_Timeline']);
    $Additional_Notes = mysqli_real_escape_string($con, $_POST['Additional_Notes']);

    $query = "INSERT INTO repair_in
    (Vehicle_Reg_No, Date_Time, Current_Driver_Name, TP_No, Mileage, Issue, Previous, Cost, Repair_Timeline, Additional_Notes) VALUES ('$Vehicle_Reg_No', '$Date_Time', '$Current_Driver_Name', '$TP_No', '$Mileage', '$Issue', '$Previous', '$Cost', '$Repair_Timeline', '$Additional_Notes')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Created Successfully";
        header("Location: repairIn-create.php");


        // Update admin_database, vehicle_details status column
        $update_status_query = "UPDATE admin_database.vehicle_details SET status='GARAGE(UNDER REPAIR)' WHERE Registration_Number='$Vehicle_Reg_No'";
        mysqli_query($con, $update_status_query);

        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Created";
        header("Location: repairIn-create.php");
        exit(0);
    }
}
?>
