<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_driver']))
{
    $driver_id = mysqli_real_escape_string($con, $_POST['delete_driver']);

    $query = "DELETE FROM driverdetails WHERE id='$driver_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Driver Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Driver Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_driver']))
{
    $driver_id = mysqli_real_escape_string($con, $_POST['driver_id']);

    $DriverRegNo = mysqli_real_escape_string($con, $_POST['DriverRegNo']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $LicenseNo = mysqli_real_escape_string($con, $_POST['LicenseNo']);
    $NICNo = mysqli_real_escape_string($con, $_POST['NICNo']);
    $TPNo = mysqli_real_escape_string($con, $_POST['TPNo']);
    $Address = mysqli_real_escape_string($con, $_POST['Address']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $DriverPhoto = mysqli_real_escape_string($con, $_POST['DriverPhoto']);

    // Handle file upload
    if(isset($_FILES['DriverPhoto']['name'])) {
        $file_name = $_FILES['DriverPhoto']['name'];
        $file_size = $_FILES['DriverPhoto']['size'];
        $file_tmp = $_FILES['DriverPhoto']['tmp_name'];
        $file_type = $_FILES['DriverPhoto']['type'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $extensions = array("jpg", "jpeg", "png");

        if(in_array($file_ext, $extensions) === false) {
            $_SESSION['message'] = "Invalid file extension. Only JPG, JPEG, and PNG files are allowed.";
            header("Location: index.php");
            exit(0);
        }

        // Move uploaded file to a directory (e.g., "uploads/")
        $upload_dir = "uploads/";
        $new_file_name = uniqid('driver_').'.'.$file_ext;
        move_uploaded_file($file_tmp, $upload_dir . $new_file_name);

        // Update the database with the file name
        $query = "UPDATE driverdetails SET DriverRegNo='$DriverRegNo', DriverName='$DriverName', LicenseNo='$LicenseNo', NICNo='$NICNo',
        TPNo='$TPNo', Address='$Address', CurrentStatus='$CurrentStatus', DriverPhoto='$new_file_name' WHERE id='$driver_id' ";
    } else {
        // Update the database without the file name
        $query = "UPDATE driverdetails SET DriverRegNo='$DriverRegNo', DriverName='$DriverName', LicenseNo='$LicenseNo', NICNo='$NICNo',
        TPNo='$TPNo', Address='$Address', CurrentStatus='$CurrentStatus', DriverPhoto='$new_file_name' WHERE id='$driver_id' ";
    }

    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Driver Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Driver Not Updated";
        header("Location: index.php");
        exit(0);
    }
}


if(isset($_POST['save_driver']))
{
    $DriverRegNo = mysqli_real_escape_string($con, $_POST['DriverRegNo']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $LicenseNo = mysqli_real_escape_string($con, $_POST['LicenseNo']);
    $NICNo = mysqli_real_escape_string($con, $_POST['NICNo']);
    $TPNo = mysqli_real_escape_string($con, $_POST['TPNo']);
    $Address = mysqli_real_escape_string($con, $_POST['Address']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $DriverPhoto = mysqli_real_escape_string($con, $_POST['DriverPhoto']);


    // Handle file upload
    if(isset($_FILES['DriverPhoto']['name'])) {
        $file_name = $_FILES['DriverPhoto']['name'];
        $file_size = $_FILES['DriverPhoto']['size'];
        $file_tmp = $_FILES['DriverPhoto']['tmp_name'];
        $file_type = $_FILES['DriverPhoto']['type'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $extensions = array("jpg", "jpeg", "png");

        if(in_array($file_ext, $extensions) === false) {
            $_SESSION['message'] = "Invalid file extension. Only JPG, JPEG, and PNG files are allowed.";
            header("Location: student-create.php");
            exit(0);
        }

        // Move uploaded file to a directory (e.g., "uploads/")
        $upload_dir = "uploads/";
        $new_file_name = uniqid('driver_').'.'.$file_ext;
        move_uploaded_file($file_tmp, $upload_dir . $new_file_name);

        // Insert the data into the database
        $query = "INSERT INTO driverdetails (DriverRegNo, DriverName, LicenseNo, NICNo, TPNo, Address, CurrentStatus, DriverPhoto)
        VALUES ('$DriverRegNo','$DriverName','$LicenseNo','$NICNo','$TPNo','$Address','$CurrentStatus','$new_file_name')";
    } else {
        // Insert the data into the database without the file name
        $query = "INSERT INTO driverdetails (DriverRegNo, DriverName, LicenseNo, NICNo, TPNo, Address, CurrentStatus, DriverPhoto)
        VALUES ('$DriverRegNo','$DriverName','$LicenseNo','$NICNo','$TPNo','$Address','$CurrentStatus', '$new_file_name')";
    }

    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Driver Created Successfully";
        header("Location: driver-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Driver Not Created";
        header("Location: driver-create.php");
        exit(0);
    }
}
?>
