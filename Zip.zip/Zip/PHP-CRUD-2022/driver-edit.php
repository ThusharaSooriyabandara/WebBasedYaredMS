<?php
session_start();
require 'dbcon.php';
?>


<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Driver Edit</title>
</head>
<style>
body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
               .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
</style>
<body>
    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
  
    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="background-color: #5D9C59; color: black;">
                        <h4>Driver Edit 
                            <a href="index.php" class="btn btn-danger float-end" style="background-color: #1A120B; color: white;">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <?php
                        if(isset($_GET['id']))
                        {
                            $driver_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM driverdetails WHERE id='$driver_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $driver = mysqli_fetch_array($query_run);
                                ?>
                                <form action="code.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="driver_id" value="<?= $driver['id']; ?>">

                                    <div class="mb-3">
                                        <label>Driver Reg. No.</label>
                                        <input type="text" name="DriverRegNo" value="<?=$driver['DriverRegNo'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>Driver Name</label>
                                        <input type="text" name="DriverName" value="<?=$driver['DriverName'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>License No</label>
                                        <input type="text" name="LicenseNo" value="<?=$driver['LicenseNo'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>NIC No</label>
                                        <input type="text" name="NICNo" value="<?=$driver['NICNo'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label>TP No</label>
                                        <input type="text" name="TPNo" value="<?=$driver['TPNo'];?>" class="form-control">
                                    </div>
                                         <div class="mb-3">
                                        <label>Address</label>
                                        <input type="text" name="Address" value="<?=$driver['Address'];?>" class="form-control">
                                    </div>
                                    <div class="mb-3">
                                        <label for="CurrentStatus">Current Status</label>
                                        <select name="CurrentStatus" id="CurrentStatus" class="form-control">
                                            <option value="Off Duty" <?= ($driver['CurrentStatus'] == 'Off Duty') ? 'selected' : ''; ?>>Off Duty</option>
                                            <option value="On Duty" <?= ($driver['CurrentStatus'] == 'On Duty') ? 'selected' : ''; ?>>On Duty</option>
                                            <option value="Driving" <?= ($driver['CurrentStatus'] == 'Driving') ? 'selected' : ''; ?>>Driving</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="DriverPhoto" class="form-label">Driver Photo</label>
                                        <input type="file" id="DriverPhoto" name="DriverPhoto" class="form-control" accept="image/*">
                                    </div>
                                    <div class="mb-3">
                                        <label for="CurrentDriverPhoto" class="form-label">Current Driver Photo</label>
                                        <br>
                                        <?php if(!empty($driver['DriverPhoto'])) { ?>
                                            <img src="uploads/<?= $driver['DriverPhoto']; ?>" alt="Driver Photo" width="200">
                                        <?php } else { ?>
                                            <span>No photo available</span>
                                        <?php } ?>
                                    </div>

                                    <div class="mb-3">
                                        <button type="submit" name="update_driver" class="btn btn-primary" style="background-color: #1A120B; color: white;">
                                            Update Driver
                                        </button>
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
