<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_vAssign']))
{
    $vAssign_id = mysqli_real_escape_string($con, $_POST['delete_vAssign']);

    $query = "DELETE FROM vehicle_assign WHERE id='$vAssign_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}

if(isset($_POST['update_vAssign']))
{
    $vAssign_id = mysqli_real_escape_string($con, $_POST['vAssign_id']);

    $DriverRegNo = mysqli_real_escape_string($con, $_POST['DriverRegNo']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $Assigned_Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Assigned_Vehicle_Reg_No']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $Trip_ID = mysqli_real_escape_string($con, $_POST['Trip_ID']);
    $Trip_Start_Date = mysqli_real_escape_string($con, $_POST['Trip_Start_Date']);
    $Trip_End_Date = mysqli_real_escape_string($con, $_POST['Trip_End_Date']);

    $query = "UPDATE vehicle_assign SET DriverRegNo='$DriverRegNo', DriverName='$DriverName', Assigned_Vehicle_Reg_No='$Assigned_Vehicle_Reg_No', CurrentStatus='$CurrentStatus', Trip_ID='$Trip_ID', Trip_Start_Date='$Trip_Start_Date', Trip_End_Date='$Trip_End_Date' WHERE id='$vAssign_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Updated";
        header("Location: index.php");
        exit(0);
    }
}


if(isset($_POST['save_vAssign']))
{
    $DriverRegNo = mysqli_real_escape_string($con, $_POST['DriverRegNo']);
    $DriverName = mysqli_real_escape_string($con, $_POST['DriverName']);
    $Assigned_Vehicle_Reg_No = mysqli_real_escape_string($con, $_POST['Assigned_Vehicle_Reg_No']);
    $CurrentStatus = mysqli_real_escape_string($con, $_POST['CurrentStatus']);
    $Trip_ID = mysqli_real_escape_string($con, $_POST['Trip_ID']);
    $Trip_Start_Date = mysqli_real_escape_string($con, $_POST['Trip_Start_Date']);
    $Trip_End_Date = mysqli_real_escape_string($con, $_POST['Trip_End_Date']);

    $query = "INSERT INTO vehicle_assign (DriverRegNo, DriverName, Assigned_Vehicle_Reg_No, CurrentStatus, Trip_ID, Trip_Start_Date, Trip_End_Date) VALUES ('$DriverRegNo','$DriverName','$Assigned_Vehicle_Reg_No','$CurrentStatus','$Trip_ID','$Trip_Start_Date','$Trip_End_Date')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Created Successfully";
        header("Location: va-create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Not Created";
        header("Location: va-create.php");
        exit(0);
    }
}
?>
