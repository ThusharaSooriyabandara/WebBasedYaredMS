<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Datepicker CSS -->
    <link href="https://cdn.jsdelivr.net/npm/datepickerjs@latest/dist/datepicker.min.css" rel="stylesheet">

    <title>Gate In Details</title>
    <style>
body {
  background-image: url('GC.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #5D9C59;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        .float-end {
            margin-left: auto;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-color: #ccc;
        }
        .btn-primary {
            background-color: #1A120B;
            border-color: #1A120B;
        }
        .btn-primary:hover {
            background-color: #1A120B;
            border-color: #1A120B;
        }
 .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
    </style>

<script>
function fetchDriverName() {
    const vehicleRegNo = document.getElementById('Vehicle_Reg_No').value;
    if (vehicleRegNo !== '') {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_driver_name.php?reg_no=' + encodeURIComponent(vehicleRegNo), true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                const driverName = response.DriverName;
                document.getElementById('DriverName').value = driverName;
                const driverPhoto = response.DriverPhoto; // Corrected variable name here
                if (driverPhoto) {
                    // Modify the path to the 'upload' folder
                    document.getElementById('DriverPhoto').src = 'uploads/' + driverPhoto; // Corrected variable name here
                } else {
                    // Use a default photo path if no driver photo is available
                    document.getElementById('DriverPhoto').src = 'no_photo_available.jpg';
                }
            }
        };

        xhr.send();
    } else {
        document.getElementById('DriverName').value = '';
        document.getElementById('DriverPhoto').src = ''; // Clear the photo if no vehicle registration number is entered.
    }
}


</script>


</head>
<body>
    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
    <div class="container">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header">
                <h4>Gate In Details</h4>
                <a href="index.php" class="btn btn-danger float-end">BACK</a>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">

<div class="mb-3">
    <label for="Vehicle_Reg_No" class="form-label">Vehicle Reg. No.</label>
    <input type="text" id="Vehicle_Reg_No" name="Vehicle_Reg_No" class="form-control" placeholder="Vehicle Reg. No." oninput="fetchDriverName()">
</div>
<div class="mb-3">
    <label for="DriverName" class="form-label">Driver Name</label>
    <input type="text" id="DriverName" name="DriverName" class="form-control" placeholder="Driver Name" readonly>
</div>





                    <div class="mb-3">
                        <label for="GateIn_Time" class="form-label">Gate in Date & Time</label>
                        <input type="datetime-local" id="GateIn_Time" name="GateIn_Time" class="form-control" placeholder="Gate in Date & Time">
                    </div>
                    
                    <div class="mb-3">
                        <button type="reset" class="btn btn-primary">Reset</button>
                        <button type="submit" name="save_gatein" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

   
</body>
</html>