<?php
$connect = mysqli_connect("localhost", "root", "", "admin_database");
$sql = "SELECT * FROM vehicle_details";  
$result = mysqli_query($connect, $sql);
?>
<html>  
 <head>  
  <title>Export MySQL data to Excel in PHP</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
    <h2 align="center">Vehicle Details</h2><br /> 
    <table class="table table-bordered">
     <tr>  
                        
                        <th>Registration_Number</th>
                        <th>Engine_Number</th>
                        <th>Chassis_No</th>
                        <th>Vehicle_Class</th>
                        <th>Taxation_Class</th>
                        <th>Make</th>
                        <th>Type_of_body</th>
                        <th>Color_1</th>
                        <th>Color_2</th>
                        <th>fual_type</th>
                        <th>Cylinder_Capacity</th>
                        <th>Responsible_Owner</th>
                        
                    </tr>
     <?php
     while($row = mysqli_fetch_array($result))  
     {  
        echo '  
       <tr>  
         
                         <td>'.$row["Registration_Number"].'</td>  
                         <td>'.$row["Engine_Number"].'</td>  
                         <td>'.$row["Chassis_No"].'</td>  
                         <td>'.$row["Vehicle_Class"].'</td>  
                         <td>'.$row["Taxation_Class"].'</td>
                         <td>'.$row["Make"].'</td>  
                         <td>'.$row["Type_of_body"].'</td>
                         <td>'.$row["Color_1"].'</td>  
                         <td>'.$row["Color_2"].'</td>  
                         <td>'.$row["fual_type"].'</td>
                         <td>'.$row["Cylinder_Capacity"].'</td>  
                         <td>'.$row["Responsible_Owner"].'</td> 
         
       </tr>  
        ';  
     }
     ?>
    </table>
    <br />
    <form method="post" action="export.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>
    <br>
                <button type="button" onclick="goBack()" class="btn btn-primary">Back</button>

   </div>  
  </div>  
 </body>
     <script>
        function goBack() {
            window.history.back();
        }
    </script>  
</html>
