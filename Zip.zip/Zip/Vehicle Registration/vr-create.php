<?php 
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Vehicle Create</title>
    <style>
body {
  background-image: url('admin main.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f8f9fa;
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        .float-end {
            margin-left: auto;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-color: #ccc;
        }
        .btn-primary {
            background-color: #1A120B;
            border-color: #1A120B;
        }
        .btn-primary:hover {
            background-color: #1A120B;
            border-color: #1A120B;
        }
 .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div> 
  
    <div class="container">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header" style="background-color: #FF6E31; color: black;">
                <h4 >Vehicle Registration</h4>
                <a href="index.php" class="btn btn-danger float-end" style="background-color: #1A120B; color: white;">BACK</a>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="Registration_Number" class="form-label">Registration Number</label>
                        <input type="text" id="Registration_Number" name="Registration_Number" class="form-control" placeholder="Registration Number" required>
                    </div>
                    <div class="mb-3">
                        <label for="Engine_Number" class="form-label">Engine Number</label>
                        <input type="text" id="Engine_Number" name="Engine_Number" class="form-control" placeholder="Engine Number">
                    </div>
                    <div class="mb-3">
                        <label for="Chassis_No" class="form-label">Chassis Number</label>
                        <input type="text" id="Chassis_No" name="Chassis_No" class="form-control" placeholder="Chassis Number">
                    </div>
                    <div class="mb-3">
                        <label for="Vehicle_Class" class="form-label">Vehicle Class</label>
                        <select id="Vehicle_Class" name="Vehicle_Class" class="form-select" required>
                            <option value="Class 1">Class 1</option>
                            <option value="Class 2">Class 2</option>
                            <option value="Class 3">Class 3</option>
                            <option value="Class 4">Class 4</option>
                            <option value="Class 5">Class 5</option>
                            <option value="Class 6">Class 6</option>
                            <option value="Class 7">Class 7</option>
                            <option value="Class 8">Class 8</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Taxation_Class" class="form-label">Taxation Class</label>
                        <select id="Taxation_Class" name="Taxation_Class" class="form-select" required>
                            <option value="6 Tyre Truck">6 Tyre Truck</option>
                            <option value="10 Tyre Multy Axie Truck">10 Tyre Multy Axie Truck</option>
                            <option value="12 Tyre Single Chassis Truck">12 Tyre Single Chassis Truck</option>
                            <option value="14 Tyre Single Chassis Rigid Truck">14 Tyre Single Chassis Rigid Truck</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Make" class="form-label">Make</label>
                        <select id="Make" name="Make" class="form-select" required>
                            <option value="MACK">MACK</option>
                            <option value="Kenworth">Kenworth</option>
                            <option value="TATA">TATA</option>
                            <option value="Isuze">Isuze</option>
                            <option value="MAZ-5440">MAZ-5440</option>
                            <option value="Foton">Foton</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Type_of_body" class="form-label">Type of Body</label>
                        <select id="Type_of_body" name="Type_of_body" class="form-select" required>
                            <option value="Flatbed">Flatbed</option>
                            <option value="Van Body">Van Body</option>
                            <option value="Dump Tipper">Dump Tipper</option>
                            <option value="Tanker">Tanker</option>
                            <option value="Tractor">Tractor</option>
                            <option value="Chassis Only">Chassis Only</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Color_1" class="form-label">Color 1</label>
                        <input type="text" id="Color_1" name="Color_1" class="form-control" placeholder="Color 1">
                    </div>
                    <div class="mb-3">
                        <label for="Color_2" class="form-label">Color 2</label>
                        <input type="text" id="Color_2" name="Color_2" class="form-control" placeholder="Color 2">
                    </div>
                    <div class="mb-3">
                        <label for="fual_type" class="form-label">Fuel Type</label>
                        <select id="fual_type" name="fual_type" class="form-select" required>
                            <option value="Diesel">Diesel</option>
                            <option value="Petrol">Petrol</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Cylinder_Capacity" class="form-label">Cylinder Capacity</label>
                        <input type="text" id="Cylinder_Capacity" name="Cylinder_Capacity" class="form-control" placeholder="Cylinder Capacity">
                    </div>
                    <div class="mb-3">
                        <label for="First_Registration" class="form-label">First Registration</label>
                        <input type="date" id="First_Registration" name="First_Registration" class="form-control" placeholder="First Registration">
                    </div>
                    <div class="mb-3">
                        <label for="Responsible_Owner" class="form-label">Responsible Owner</label>
                        <input type="text" id="Responsible_Owner" name="Responsible_Owner" class="form-control" placeholder="Responsible Owner">
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Current Status</label>
                        <select id="status" name="status" class="form-select" required>
                            <option value="REPAIR COMPLETE">REPAIR COMPLETE</option>
                            <option value="NOT IN USE">NOT IN USE</option>
                            <option value="GARAGE(UNDER REPAIR)">GARAGE(UNDER REPAIR)</option>
                            <option value="RUNNING CONDITION">RUNNING CONDITION</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="Remarks" class="form-label">Remarks</label>
                        <input type="text" id="Remarks" name="Remarks" class="form-control" placeholder="Remarks">
                    </div>
                    <div class="mb-3">
                        <label for="Vehicle_Photo" class="form-label">Vehicle Photo</label>
                        <input type="file" id="Vehicle_Photo" name="Vehicle_Photo" class="form-control" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <button type="reset" class="btn btn-primary" style="background-color: #1A120B; color: white;">Reset</button>
                        <button type="submit" name="save_vehicle" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
