<?php
// Assuming you have a database connection established already
// Replace 'your_database_hostname', 'your_database_username', 'your_database_password', and 'your_database_name' with your actual database credentials.
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'admin_database';

$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['reg_no'])) {
    $vehicleRegNo = $_GET['reg_no'];

    // Assuming your table is named 'vehicle_assign' and the driver name is in the 'DriverName' column.
    $query = "SELECT DriverName FROM vehicle_assign WHERE Assigned_Vehicle_Reg_No = '" . mysqli_real_escape_string($conn, $vehicleRegNo) . "'";

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $driverName = $row['DriverName'];

        $queryPhoto = "SELECT DriverPhoto FROM driverdetails WHERE DriverName = '" . mysqli_real_escape_string($conn, $driverName) . "'";

        $resultPhoto = mysqli_query($conn, $queryPhoto);

        if ($resultPhoto && mysqli_num_rows($resultPhoto) > 0) {
            $rowPhoto = mysqli_fetch_assoc($resultPhoto);
            $driverPhoto = $rowPhoto['DriverPhoto'];

            // Combine the driver name and photo into a JSON response.
            $response = array(
                'DriverName' => $driverName,
                'DriverPhoto' => 'uploads/' . $driverPhoto // Add the correct path to the 'upload' folder
            );

            echo json_encode($response);
        } else {
            // If no photo is available, send a default photo path
            $response = array(
                'DriverName' => $driverName,
                'DriverPhoto' => 'no_photo_available.jpg'
            );

            echo json_encode($response);
        }
    } else {
        // If no driver name is found, send an empty response
        $response = array(
            'DriverName' => '',
            'DriverPhoto' => ''
        );

        echo json_encode($response);
    }
}

mysqli_close($conn);
?>
