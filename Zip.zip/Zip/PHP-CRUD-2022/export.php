<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "admin_database");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM driverdetails";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                        <th>DriverRegNo</th>
                        <th>DriverName</th>
                        <th>LicenseNo</th>
                        <th>NICNo</th>
                        <th>TPNo</th>
                        <th>Address</th>
                        <th>CurrentStatus</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["DriverRegNo"].'</td>  
                         <td>'.$row["DriverName"].'</td>  
                         <td>'.$row["LicenseNo"].'</td>  
                         <td>'.$row["NICNo"].'</td>  
                         <td>'.$row["TPNo"].'</td>
                         <td>'.$row["Address"].'</td>  
                         <td>'.$row["CurrentStatus"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>