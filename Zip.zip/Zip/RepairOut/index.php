<?php
session_start();
require 'dbcon.php';
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <title>Repair Out CRUD</title>

    <style>
         body {
  background-image: url('vehicleOperatorMain.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
  opacity: 1;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            margin-top: 2rem;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #6C3428;
        }

        .float-end {
            margin-left: auto;
        }

        th {
            text-align: center;
        }


        .btn-action {
            margin-right: 5px;
        }

        .no-records {
            text-align: center;
            margin-top: 1rem;
        }

        .custom-header {
            background-color: #5D9C59;
            color: #1A120B;
            padding: 1rem;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.1);
        }

        .custom-header h2 {
            margin: 0;
            font-size: 24px;
            font-smooth: 20%;

        }

        .custom-header .btn-primary {
            background-color: #1A120B; /* Change the button color to green */
            border-color: #1A120B; /* Change the border color to green */
            margin-left: 10px;
        }

        .search-bar {
            margin-top: 1rem;
            display: flex;
            justify-content: flex-end;
        }

        .search-input {
            max-width: 200px;
            margin-right: 10px;
        }
    .btn-view {
        background-color: #1A120B;
        border-color: #1A120B;
    }
            .header {
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            width: 100%;
            
            top: 0;
            left: 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        .logo img {
            vertical-align: middle;
            height: 80px;
            width: 80px;
            margin-right: 10px;
        }
        .nav-links {
            margin-right: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            padding: 10px 15px;
            border-radius: 5px;
        }

        /* Added styles for the small pie chart */
        .small-pie-chart {
            max-width: 200px;
            margin: 0 auto;
            margin-top: 2rem;
        }
        .button-container {
  text-align: right;
}
    </style>
</head>

<body>
    <div class="header">
        <a class="logo" href="#home">
            <img src="logo.png" alt="Logo">
           
        </a>
        <div class="nav-links">

            <a href="/loginpage/first_main_page.php">Home</a>
            <a href="#">About</a>
            <a href="#">Contact</a>
        </div>
    </div>
    </style>
</head>

<body>
    <div class="container">
        <?php include('message.php'); ?>

        <div class="card">
            <div class="card-header">
                <h4>Repair Out Details</h4>
                <div class="button-container">

                <a href="repairOut-create.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Add Repair Out Data</a>
                                <a href="/loginpage/vehicle operator.php" class="btn btn-primary float-end" style="background-color: #1A120B; color: white;">Vehicle Operator Home</a>
                    </div>
            </div>
            <div class="card-body">
                <?php
                $query = "SELECT * FROM repair_Out
";
                $query_run = mysqli_query($con, $query);

                if (mysqli_num_rows($query_run) > 0) {
                ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Vehicle Reg. No.</th>
                                <th>Repair Out Date & Time</th>
                                <th>Driver Name</th>
                                <th>TP No</th>
                                <th>Repair Type</th>
                                <th>Estimate Cost</th>
                                <th>Additional Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($repairOut= mysqli_fetch_assoc($query_run)) {
                                ?>
                                <tr>
                                    <td><?= $repairOut['id']; ?></td>
                                    <td><?= $repairOut['Vehicle_Reg_No']; ?></td>
                                    <td><?= $repairOut['Date_Time']; ?></td>
                                    <td><?= $repairOut['Driver_Name']; ?></td>
                                    <td><?= $repairOut['TP_No']; ?></td>
                                    <td><?= $repairOut['Repair_Type']; ?></td>
                                    <td><?= $repairOut['Cost']; ?></td>
                                    <td><?= $repairOut['Additional_Notes']; ?></td>
                                    <td>
                                        <a href="repairOut-view.php?id=<?= $repairOut ['id']; ?>" class="btn btn-info btn-sm btn-action">View</a>
                                        <a href="repairOut-edit.php?id=<?= $repairOut['id']; ?>" class="btn btn-success btn-sm btn-action">Edit</a>
                                        <form action="code.php" method="POST" class="d-inline">
                                            <button type="submit" name="delete_repairOut" value="<?= $repairOut['id']; ?>" class="btn btn-danger btn-sm btn-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                <?php
                } else {
                    echo '<div class="no-records"><h5>No Records Found</h5></div>';
                }
                ?>

                <!-- Small Pie Chart -->
                <div class="small-pie-chart">
                    <canvas id="statusPieChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script>
        <?php
        // Fetching data for pie chart
        $statusData = array();
        $query = "SELECT CurrentStatus, COUNT(*) AS Count FROM repair_in
 GROUP BY CurrentStatus";
        $result = mysqli_query($con, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            $statusData[$row['CurrentStatus']] = $row['Count'];
        }
        ?>

        // Pie Chart Initialization
        var pieCtx = document.getElementById('statusPieChart').getContext('2d');
        var pieChart = new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: <?= json_encode(array_keys($statusData)); ?>,
                datasets: [{
                    data: <?= json_encode(array_values($statusData)); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>