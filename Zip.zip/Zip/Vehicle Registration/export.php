<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "admin_database");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM vehicle_details";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                        <th>Registration_Number</th>
                        <th>Engine_Number</th>
                        <th>Chassis_No</th>
                        <th>Vehicle_Class</th>
                        <th>Taxation_Class</th>
                        <th>Make</th>
                        <th>Type_of_body</th>
                        <th>Color_1</th>
                        <th>Color_2</th>
                        <th>fual_type</th>
                        <th>Cylinder_Capacity</th>
                        <th>Responsible_Owner</th>
                    
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["Registration_Number"].'</td>  
                         <td>'.$row["Engine_Number"].'</td>  
                         <td>'.$row["Chassis_No"].'</td>  
                         <td>'.$row["Vehicle_Class"].'</td>  
                         <td>'.$row["Taxation_Class"].'</td>
                         <td>'.$row["Make"].'</td>  
                         <td>'.$row["Type_of_body"].'</td>
                         <td>'.$row["Color_1"].'</td>  
                         <td>'.$row["Color_2"].'</td>  
                         <td>'.$row["fual_type"].'</td>
                         <td>'.$row["Cylinder_Capacity"].'</td>  
                         <td>'.$row["Responsible_Owner"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>